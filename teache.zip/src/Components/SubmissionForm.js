import React from "react";

const SubmissionForm = () => {
  return (
    <div>
      <h1>Form يا غالي</h1>
    </div>
  );
};

export default SubmissionForm;
