import React from "react";

const ContactUs = () => {
  return (
    <div>
      <h1>أعطينا مكالمة يا كبير</h1>
    </div>
  );
};

export default ContactUs;
