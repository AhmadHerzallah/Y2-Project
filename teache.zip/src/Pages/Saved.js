import React from "react";

const Saved = () => {
  return (
    <div>
      <h1>Saved</h1>
    </div>
  );
};

export default Saved;
